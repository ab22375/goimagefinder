
Image Finder Tool
-----------------

Usage:
  ./image-finder scan --folder=PATH [--database=PATH] [--prefix=NAME] [--force]
  ./image-finder search --image=PATH [--database=PATH] [--threshold=VALUE] [--prefix=NAME]

Examples:
  ./image-finder scan --folder=/path/to/images --prefix=ExternalDrive1
  ./image-finder search --image=/path/to/query.jpg --threshold=0.85

